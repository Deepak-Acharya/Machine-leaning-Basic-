# customer_satisfaction
To determine whether the customer is happy with the chatbot's responses, I should gather the conversation from the database, use Natural Language Processing algorithms, and collect the outcomes.
