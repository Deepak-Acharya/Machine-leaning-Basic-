MODEL_PATH = "app/model/sentiment_analysis"
REMOVE_UNWANTED_SYMBOLS = "[^a-zA-Z0-9(+*) \n\.]"
REMOVE_UNWANTED_SPACES = "\s+"
